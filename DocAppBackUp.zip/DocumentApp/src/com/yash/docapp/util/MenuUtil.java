package com.yash.docapp.util;

public class MenuUtil {

	public static void printMenu() {
		System.out.println("-----------Main Menu-------------");
		System.out.println("1. Create Document");
		System.out.println("2. List Document");
		System.out.println("3. Search Document");
		System.out.println("4. Find Document by Id");
		System.out.println("5. Delete Document");
		System.out.println("6. Sort Document");
		System.out.println("0. Exit");
		
	}

}
