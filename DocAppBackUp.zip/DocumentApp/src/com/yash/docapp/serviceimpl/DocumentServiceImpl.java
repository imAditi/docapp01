package com.yash.docapp.serviceimpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.yash.docapp.dao.DocumentDAO;
import com.yash.docapp.domain.Document;
import com.yash.docapp.repository.Repository;
import com.yash.docapp.service.DocumentService;

public class DocumentServiceImpl implements DocumentService {

	private DocumentDAO documentdao;

	public DocumentServiceImpl(DocumentDAO documentdao) {
		this.documentdao = documentdao;
	}

	@Override
	public void addDocument(Document document) {
		documentdao.insert(document);

	}

	@Override
	public void updateDocument(Document document) {
		documentdao.update(document);

	}

	@Override
	public void deleteDocument(int id) {
		documentdao.delete(id);

	}

	@Override
	public List<Document> listDocument() {

		List<Document> documentList = documentdao.list();

		if (documentList.size() == 0) {
			System.out.println("Warning : no data available !");
		}
		return documentList;
	}

	@Override
	public List<Document> sortDocument() {
		List<Document> documents = documentdao.list();
		List<Document> filterlist = new ArrayList();
		Collections.sort(documents,new Sorting());
		for (Document doc : documents) {
			
			filterlist.add(doc);
		}
	return filterlist;
	}

	@Override
	public List<Document> serachDocument(String searchTitle) {
		List<Document> documents = documentdao.list();
		List<Document> filterlist = new ArrayList();
		for (Document doc : documents) {
			if (doc.getTitle().contains(searchTitle)) {
				filterlist.add(doc);
			}
		}
		return filterlist;
	}

	@Override
	public Document findById(int id) {
		// TODO
		return null;
	}

}
